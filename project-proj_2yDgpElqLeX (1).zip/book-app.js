class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) { return { hasError: true, error }; }
  componentDidCatch(error, errorInfo) { console.error('ErrorBoundary:', error, errorInfo); }
  render() {
    if (this.state.hasError) return <div className="p-8 text-center text-red-500">Error loading dashboard</div>;
    return this.props.children;
  }
}

function DashboardTabs() {
    const [activeTab, setActiveTab] = React.useState('ride_now');
    return (
        <div className="flex border-b border-gray-200 bg-white">
            <button 
                onClick={() => setActiveTab('ride_now')} 
                className={`flex-1 py-4 text-sm font-bold transition-colors border-b-2 ${activeTab === 'ride_now' ? 'border-[var(--accent-color)] text-[var(--accent-color)]' : 'border-transparent text-gray-500 hover:text-white'}`}
            >
                Ride Now
            </button>
            <button 
                onClick={() => setActiveTab('schedule')} 
                className={`flex-1 py-4 text-sm font-bold transition-colors border-b-2 ${activeTab === 'schedule' ? 'border-[var(--accent-color)] text-[var(--accent-color)]' : 'border-transparent text-gray-500 hover:text-white'}`}
            >
                Schedule Ride
            </button>
        </div>
    );
}

function App() {
  try {
    const [currentUser, setCurrentUser] = React.useState(null);
    const [stats, setStats] = React.useState({ totalRides: '-', totalSpent: '-', activeDrivers: '-' });
    const [currentView, setCurrentView] = React.useState('dashboard'); // dashboard, booking
    const [bookingStep, setBookingStep] = React.useState('search');
    const [destination, setDestination] = React.useState('');
    const [onlineDrivers, setOnlineDrivers] = React.useState([]);
    const [activeRide, setActiveRide] = React.useState(null);

    React.useEffect(() => {
        const user = window.getCurrentUser ? window.getCurrentUser() : null;
        if (!user) window.location.href = 'auth.html';
        else setCurrentUser(user);
    }, []);

    React.useEffect(() => {
        if (!currentUser) return;
        const fetchStats = async () => {
            try {
                const [ridesRes, usersRes] = await Promise.all([
                    trickleListObjects('ride', 100, true, undefined),
                    trickleListObjects('user', 200, true, undefined)
                ]);
                
                let ridesCount = 0;
                let spent = 0;
                if (ridesRes && ridesRes.items) {
                    const myRides = ridesRes.items.filter(r => r.objectData.RiderId === currentUser.id && r.objectData.Status === 'completed');
                    ridesCount = myRides.length;
                    myRides.forEach(r => {
                        const fareStr = String(r.objectData.Fare || '0');
                        const match = fareStr.match(/\d+(?:,\d+)*(?:\.\d+)?/);
                        if (match) {
                            spent += parseFloat(match[0].replace(/,/g, ''));
                        }
                    });
                }
                
                let driversCount = 0;
                if (usersRes && usersRes.items) {
                    driversCount = usersRes.items.filter(u => u.objectData.Role === 'Driver' && u.objectData.Status === 'Online').length;
                }
                
                setStats({ 
                    totalRides: ridesCount, 
                    totalSpent: `₦${spent.toLocaleString()}`, 
                    activeDrivers: driversCount 
                });
            } catch (err) {
                console.warn('Failed to fetch stats:', err.message);
                setStats({ totalRides: 0, totalSpent: '₦0', activeDrivers: 0 });
            }
        };
        fetchStats();
    }, [currentUser]);

    // Poll for online drivers and active ride
    React.useEffect(() => {
        if (!currentUser) return;
        const fetchLiveTracking = async () => {
            try {
                const [usersRes, ridesRes] = await Promise.all([
                    trickleListObjects('user', 100, true, undefined),
                    trickleListObjects('ride', 50, true, undefined)
                ]);
                
                if (usersRes && usersRes.items) {
                    const drivers = usersRes.items.filter(u => u.objectData.Role === 'Driver' && u.objectData.Status === 'Online');
                    setOnlineDrivers(drivers);
                }

                if (ridesRes && ridesRes.items) {
                    const myActiveRide = ridesRes.items.find(r => 
                        r.objectData.RiderId === currentUser.id && 
                        ['request', 'accepted', 'en_route', 'payment_pending'].includes(r.objectData.Status)
                    );
                    setActiveRide(myActiveRide || null);
                    
                    if (myActiveRide && currentView !== 'booking') {
                        setCurrentView('booking');
                    }
                }
            } catch (err) {
                console.warn('Live tracking failed:', err.message);
            }
        };
        fetchLiveTracking();
        const interval = setInterval(fetchLiveTracking, 5000);
        return () => clearInterval(interval);
    }, [currentUser, currentView]);

    const handleBookRide = async (driverId) => {
        if (!destination) return;
        try {
            const rideData = {
                RiderId: currentUser.id,
                Pickup: 'Current Location',
                Dropoff: destination,
                Status: 'request',
                Fare: '₦' + (Math.floor(Math.random() * 3000) + 1500).toLocaleString()
            };
            
            if (driverId) {
                rideData.DriverId = driverId;
            }

            const newRide = await trickleCreateObject('ride', rideData);
            setActiveRide({ objectId: newRide.objectId, objectData: newRide.objectData });
            alert('Ride requested successfully!');
        } catch (e) {
            alert('Failed to request ride.');
        }
    };

    if (!currentUser) return null;

    if (currentView === 'booking') {
        return (
            <div className="h-screen flex flex-col md:flex-row overflow-hidden" data-name="booking-view">
                <Header currentUser={currentUser} />
                <div className="flex-1 relative order-1 md:order-2 h-[50vh] md:h-full">
                    <MapArea destination={destination} availableDrivers={onlineDrivers} activeRide={activeRide} />
                    <button onClick={() => setCurrentView('dashboard')} className="absolute top-4 left-4 z-20 bg-white p-3 rounded-full shadow-lg text-gray-800 hover:bg-gray-100">
                        <div className="icon-arrow-left text-xl"></div>
                    </button>
                </div>
                <div className="w-full md:w-96 lg:w-[400px] h-[50vh] md:h-full flex flex-col order-2 md:order-1 border-r border-gray-200 shadow-2xl relative z-10 bg-white">
                    <BookingPanel 
                        step={bookingStep}
                        destination={destination}
                        availableDrivers={onlineDrivers}
                        onSearch={(dest) => { setDestination(dest); setBookingStep('options'); }}
                        onBack={() => setBookingStep('search')}
                        onConfirm={handleBookRide}
                        rideHistory={[]}
                    />
                </div>
            </div>
        );
    }

    return (
      <div className="min-h-screen bg-gray-50 flex flex-col relative pb-24" data-name="new-dashboard">
        <Header currentUser={currentUser} />
        
        {/* Main Scrolling Content */}
        <div className="flex-1 w-full max-w-md mx-auto bg-white shadow-sm md:max-w-2xl lg:max-w-4xl min-h-screen border-x border-gray-200">
            
            {/* Tabs */}
            <DashboardTabs />

            {/* Hero / Banner with Marquee */}
            <div className="relative w-full h-48 md:h-64 bg-black overflow-hidden group">
                {/* Marquee */}
                <div className="absolute top-0 left-0 right-0 bg-[var(--accent-color)] text-white text-xs font-bold py-1.5 z-20 flex whitespace-nowrap overflow-hidden">
                    <div className="animate-marquee inline-block px-4 tracking-wide">
                        ⚡ SAVE 20% ON AIRPORT RIDES TODAY • 🔥 INVITE FRIENDS AND GET ₦1,500 • 🚀 NEW COMFORT+ DRIVERS ADDED 
                    </div>
                </div>
                
                <img src="https://images.unsplash.com/photo-1449824913935-59a10b8d2000?auto=format&fit=crop&w=1920&q=80" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700" alt="Ride Hero" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6 text-white z-10">
                    <h2 className="text-3xl font-bold tracking-tight mb-2">Move smoothly</h2>
                    <p className="text-gray-300">Reliable rides, anytime you need them.</p>
                </div>
            </div>

            <div className="p-4 md:p-8 space-y-8">
                
                {/* Title Row */}
                <div className="flex items-center justify-between">
                    <h1 className="text-xl font-bold text-gray-900 tracking-wide">Ride Dashboard</h1>
                    <div className="flex items-center gap-4 text-gray-500">
                        <button className="flex items-center gap-1.5 hover:text-white transition-colors bg-gray-50 px-3 py-1.5 rounded-full border border-gray-200"><div className="icon-heart text-red-500"></div> <span className="text-xs font-bold">100</span></button>
                        <button className="hover:text-white transition-colors bg-gray-50 p-1.5 rounded-full border border-gray-200"><div className="icon-share-2"></div></button>
                    </div>
                </div>

                {/* Quick Actions Cards */}
                <div className="grid grid-cols-3 gap-4">
                    <button onClick={() => setCurrentView('booking')} className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-col items-center justify-center gap-3 hover:bg-gray-100 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-sm border border-gray-200">
                            <div className="icon-car text-xl"></div>
                        </div>
                        <span className="text-[11px] md:text-sm font-bold text-gray-900 text-center">Book<br/>Ride</span>
                    </button>
                    <button onClick={() => window.location.href='profile.html?tab=history'} className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-col items-center justify-center gap-3 hover:bg-gray-100 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-sm border border-gray-200">
                            <div className="icon-star text-xl"></div>
                        </div>
                        <span className="text-[11px] md:text-sm font-bold text-gray-900 text-center">Rate<br/>Trip</span>
                    </button>
                    <button className="bg-gray-50 border border-gray-200 rounded-2xl p-4 flex flex-col items-center justify-center gap-3 hover:bg-gray-100 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center shadow-sm border border-gray-200">
                            <div className="icon-user-plus text-xl"></div>
                        </div>
                        <span className="text-[11px] md:text-sm font-bold text-gray-900 text-center">Refer &<br/>Earn</span>
                    </button>
                </div>

                {/* Stats Card */}
                <div className="w-full bg-[#121212] border border-[#2a2a2a] rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
                    <div className="absolute -right-6 -bottom-6 text-white/5">
                        <div className="icon-chart-bar text-9xl"></div>
                    </div>
                    <div className="relative z-10">
                        <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-5">My Summary</h3>
                        <div className="flex flex-col gap-3 font-mono text-sm">
                            <div className="flex justify-between items-center bg-[#1f1f1f] p-3 rounded-lg border border-[#2a2a2a]">
                                <span className="text-gray-400">Total Rides:</span>
                                <span className="font-bold text-lg text-white">{stats.totalRides}</span>
                            </div>
                            <div className="flex justify-between items-center bg-[#1f1f1f] p-3 rounded-lg border border-[#2a2a2a]">
                                <span className="text-gray-400">Total Spent:</span>
                                <span className="font-bold text-lg text-white">{stats.totalSpent}</span>
                            </div>
                            <div className="flex justify-between items-center bg-[#1f1f1f] p-3 rounded-lg border border-[#2a2a2a]">
                                <span className="text-gray-400">Active Drivers:</span>
                                <span className="font-bold text-lg text-[var(--accent-color)]">{stats.activeDrivers}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Primary CTA Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button onClick={() => setCurrentView('booking')} className="w-full py-4 px-6 rounded-2xl bg-[var(--primary-color)] text-black font-bold border border-gray-200 hover:bg-gray-200 transition-all flex items-center justify-between group">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-black/10 flex items-center justify-center">
                                <div className="icon-search text-black text-sm"></div>
                            </div>
                            <span className="tracking-wide">FIND DRIVERS</span>
                        </div>
                        <div className="icon-arrow-right transform group-hover:translate-x-1 transition-transform"></div>
                    </button>
                    <button onClick={() => window.location.href='profile.html?tab=history'} className="w-full py-4 px-6 rounded-2xl bg-[#121212] text-white border border-[#2a2a2a] font-bold hover:bg-[#1f1f1f] transition-all flex items-center justify-between group">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                                <div className="icon-car text-white text-sm"></div>
                            </div>
                            <span className="tracking-wide">MY RIDES</span>
                        </div>
                        <div className="icon-arrow-right transform group-hover:translate-x-1 transition-transform"></div>
                    </button>
                </div>

                {/* Bottom Tabs matching the reference "Comments/Highlights/Testimonies" */}
                <div className="pt-8 border-t border-gray-200">
                    <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-2">
                        <button className="bg-black text-white px-5 py-2.5 rounded-full text-sm font-bold flex-shrink-0">Activity</button>
                        <button className="bg-gray-50 border border-gray-200 text-gray-600 hover:bg-gray-100 hover:text-black px-5 py-2.5 rounded-full text-sm font-bold flex-shrink-0 transition-colors">Promos</button>
                        <button className="bg-gray-50 border border-gray-200 text-gray-600 hover:bg-gray-100 hover:text-black px-5 py-2.5 rounded-full text-sm font-bold flex-shrink-0 transition-colors">Reviews</button>
                    </div>
                    
                    <div className="mt-6 p-6 bg-gray-50 border border-gray-200 rounded-xl text-center text-sm text-gray-500">
                        No recent activity to show.
                    </div>
                </div>

            </div>
        </div>

        {/* Floating Action Button */}
        <button onClick={() => setCurrentView('booking')} className="fixed bottom-6 right-6 md:bottom-10 md:right-10 bg-[var(--accent-color)] text-white pl-4 pr-5 py-4 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center gap-2 group z-30">
            <div className="icon-car text-xl"></div>
            <span className="font-bold tracking-wide">REQUEST RIDE</span>
        </button>

      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);