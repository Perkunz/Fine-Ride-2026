function Header({ currentUser, onMenuClick }) {
  try {
    const [menuOpen, setMenuOpen] = React.useState(false);

    return (
      <React.Fragment>
        {/* Sticky Top Bar */}
        <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-gray-100 w-full" data-name="header" data-file="components/Header.js">
          <div className="flex items-center justify-between px-4 py-3 max-w-7xl mx-auto">
            <div className="flex items-center gap-3">
              <button onClick={() => setMenuOpen(true)} className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-800">
                <div className="icon-menu text-2xl"></div>
              </button>
              <div className="flex items-center gap-1.5 bg-gray-50 px-3 py-1 rounded-full border border-gray-200">
                <div className="icon-flame text-gray-500 text-sm"></div>
                <span className="text-xs font-bold text-gray-700 tracking-wide">3 RIDES THIS WEEK</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <button className="relative p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-600">
                <div className="icon-bell text-xl"></div>
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[var(--accent-color)] border-2 border-white rounded-full"></span>
              </button>
              <a href="profile.html" className="w-10 h-10 rounded-full p-0.5 bg-gray-200 flex items-center justify-center shadow-sm border border-gray-300">
                <div className="w-full h-full bg-white rounded-full overflow-hidden flex items-center justify-center text-gray-600 font-bold">
                  {currentUser?.Avatar ? (
                      <img src={currentUser.Avatar} className="w-full h-full object-cover" alt="Profile" />
                  ) : (
                      (currentUser?.Name || 'U').charAt(0).toUpperCase()
                  )}
                </div>
              </a>
            </div>
          </div>
        </header>

        {/* Side Drawer Navigation */}
        {menuOpen && (
            <div className="fixed inset-0 z-50 flex" data-name="side-drawer">
                <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setMenuOpen(false)}></div>
                <div className="relative w-[85%] max-w-[320px] bg-white h-full shadow-2xl flex flex-col animate-slide-right overflow-y-auto">
                    {/* Profile Section Top */}
                    <div className="p-6 pt-8 pb-8 flex flex-col items-center border-b border-gray-100 relative bg-gray-50">
                        <button onClick={() => setMenuOpen(false)} className="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-800">
                            <div className="icon-x text-xl"></div>
                        </button>
                        <div className="w-20 h-20 rounded-full p-1 bg-gray-200 border border-gray-300 mb-3 shadow-sm">
                            <div className="w-full h-full bg-white rounded-full overflow-hidden flex items-center justify-center text-gray-600 text-2xl font-bold">
                                {currentUser?.Avatar ? (
                                    <img src={currentUser.Avatar} className="w-full h-full object-cover" />
                                ) : (
                                    (currentUser?.Name || 'U').charAt(0).toUpperCase()
                                )}
                            </div>
                        </div>
                        <div className="flex items-center gap-1.5 mb-1">
                            <h3 className="font-bold text-lg text-gray-900">{currentUser?.Name || 'Rider'}</h3>
                            <div className="icon-badge-check text-blue-500 text-sm"></div>
                        </div>
                        <p className="text-sm text-gray-500">{currentUser?.Email || 'user@fineride.com'}</p>
                    </div>

                    {/* Grouped Menu Items */}
                    <div className="flex-1 px-4 py-6 space-y-8">
                        <div>
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-[0.15em] mb-3 px-3">Dashboard</h4>
                            <div className="space-y-1">
                                <a href="book.html" className="flex items-center justify-between px-3 py-3 rounded-xl bg-gray-100 text-gray-900 font-bold group">
                                    <div className="flex items-center gap-3">
                                        <div className="icon-house text-xl"></div>
                                        <span>Home</span>
                                    </div>
                                    <div className="w-1.5 h-1.5 rounded-full bg-[var(--accent-color)]"></div>
                                </a>
                                <a href="book.html" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-map text-xl"></div>
                                    <span>Ride Map</span>
                                </a>
                                <a href="profile.html?tab=history" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-clock text-xl"></div>
                                    <span>My Rides</span>
                                </a>
                            </div>
                        </div>

                        <div>
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-[0.15em] mb-3 px-3">Account</h4>
                            <div className="space-y-1">
                                <a href="profile.html?tab=profile" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-user text-xl"></div>
                                    <span>Profile</span>
                                </a>
                                <a href="profile.html?tab=payment" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-wallet text-xl"></div>
                                    <span>Payment Methods</span>
                                </a>
                                <a href="profile.html?tab=preferences" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-settings text-xl"></div>
                                    <span>Settings</span>
                                </a>
                            </div>
                        </div>

                        <div>
                            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-[0.15em] mb-3 px-3">Support</h4>
                            <div className="space-y-1">
                                <a href="profile.html?tab=profile" className="flex items-center gap-3 px-3 py-3 rounded-xl text-gray-600 hover:bg-white hover:text-gray-900 font-medium transition-colors">
                                    <div className="icon-circle-help text-xl"></div>
                                    <span>Help Center</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div className="p-6 border-t border-gray-200/60 mt-auto">
                        <button onClick={() => typeof logout === 'function' && logout()} className="flex items-center justify-center gap-2 text-[#D32F2F] hover:bg-red-50 py-3 rounded-xl font-bold transition-colors w-full">
                            <div className="icon-log-out text-lg"></div>
                            Sign Out
                        </button>
                    </div>
                </div>
            </div>
        )}
      </React.Fragment>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}